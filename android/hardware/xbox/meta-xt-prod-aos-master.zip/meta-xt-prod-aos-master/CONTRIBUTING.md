If you are interested in contribution to xen-troops projects, please follow guide lines described in
https://github.com/xen-troops/xen-troops.github.io/blob/master/CONTRIBUTING.md
